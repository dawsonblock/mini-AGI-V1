from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from egai.common.canonical import digest, validate_digest


@dataclass(frozen=True)
class ColabCampaignPlanV161:
    campaign_id: str
    model_id: str
    model_revision: str
    dataset_partition_digest: str
    scorer_artifact_digest: str
    retention_artifact_digest: str
    security_artifact_digest: str
    seeds: tuple[int, ...]
    minimum_forward_transfer: float = 0.0
    minimum_retention: float = 0.95
    require_zero_security_regressions: bool = True
    schema: str = "mini-agi-v16.1-colab-campaign-plan-v1"

    def __post_init__(self):
        if not self.campaign_id or not self.model_id or not self.model_revision:
            raise ValueError("campaign_id/model_id/model_revision required")
        for x in (self.dataset_partition_digest, self.scorer_artifact_digest,
                  self.retention_artifact_digest, self.security_artifact_digest):
            validate_digest(x)
        if not self.seeds or any(int(x) < 0 for x in self.seeds):
            raise ValueError("non-negative preregistered seeds required")
        if len(set(self.seeds)) != len(self.seeds):
            raise ValueError("duplicate campaign seeds")
        if not 0 <= self.minimum_retention <= 1:
            raise ValueError("minimum_retention must be in [0,1]")

    @property
    def digest(self) -> str:
        return digest(self)


ALLOWED_ARMS_V162 = ("L1", "L2", "L3", "L4", "L5", "L6", "NC")

#: v16.6 vocabulary additions (SCI-302 / 3B Step 10): the self-verified
#: replay alias, the independently verified replay baseline and the
#: adapter-plus-verified-replay arm. Validation-only — the V162 default
#: tuple above is unchanged, so historical plan digests are untouched.
ALLOWED_ARMS_V166 = ALLOWED_ARMS_V162 + ("L5a", "L5b", "L7")


@dataclass(frozen=True)
class ColabCampaignPlanV162:
    """Six-arm campaign plan (v16.2).

    Arms: L1 frozen, L2 retrieval, L3 semantic-memory, L4 skills,
    L5 grounded-replay, L6 neural-adapter, NC negative control
    (label-shuffled LoRA).

    GPU nondeterminism policy (preregistered):
      * reproduction_semantics = "statistical-equivalence": independent
        reproduction requires metric agreement within metric_tolerance,
        never bit-identical artifacts.
      * adapter_bitwise_required = False: CUDA training is not
        bit-deterministic across runtimes; every produced adapter must
        instead carry its own digest and qualification lineage.
      * Primary comparison is mean(L6_hidden - L5_hidden) over seeds
        (incremental forward transfer beyond grounded replay).
    """
    campaign_id: str
    model_id: str
    model_revision: str
    dataset_partition_digest: str
    scorer_artifact_digest: str
    retention_artifact_digest: str
    security_artifact_digest: str
    seeds: tuple[int, ...]
    arms: tuple[str, ...] = ALLOWED_ARMS_V162
    negative_control_arm: str = "NC"
    negative_control_max_ft: float = 0.02
    minimum_neural_incremental_ft: float = 0.02
    minimum_retention: float = 0.95
    require_zero_security_regressions: bool = True
    reproduction_semantics: str = "statistical-equivalence"
    adapter_bitwise_required: bool = False
    metric_tolerance: float = 0.05
    schema: str = "mini-agi-v16.2-colab-campaign-plan-v1"

    def __post_init__(self):
        if not self.campaign_id or not self.model_id or not self.model_revision:
            raise ValueError("campaign_id/model_id/model_revision required")
        for x in (self.dataset_partition_digest, self.scorer_artifact_digest,
                  self.retention_artifact_digest, self.security_artifact_digest):
            validate_digest(x)
        if not self.seeds or any(int(x) < 0 for x in self.seeds):
            raise ValueError("non-negative preregistered seeds required")
        if len(set(self.seeds)) != len(self.seeds):
            raise ValueError("duplicate campaign seeds")
        arms = tuple(self.arms)
        unknown = [a for a in arms if a not in ALLOWED_ARMS_V166]
        if unknown:
            raise ValueError(f"unknown arms: {unknown}")
        for required in ("L1", "L5", "L6", "NC"):
            # L5a is the v16.6 spelling of the self-verified replay arm
            # and satisfies the L5 requirement.
            if required not in arms and not (required == "L5"
                                             and "L5a" in arms):
                raise ValueError(f"required arm {required} missing from plan")
        if self.negative_control_arm not in arms:
            raise ValueError("negative control arm not in plan arms")
        if not 0 <= self.minimum_retention <= 1:
            raise ValueError("minimum_retention must be in [0,1]")
        if self.metric_tolerance < 0 or self.negative_control_max_ft < 0:
            raise ValueError("tolerances must be non-negative")
        if self.reproduction_semantics != "statistical-equivalence":
            raise ValueError("reproduction semantics must be statistical-equivalence")
        if self.adapter_bitwise_required:
            raise ValueError("adapter bitwise reproduction is prohibited by policy")
        object.__setattr__(self, "arms", arms)
        object.__setattr__(self, "seeds", tuple(int(s) for s in self.seeds))

    @property
    def digest(self) -> str:
        return digest(self)


@dataclass(frozen=True)
class ColabCampaignPlanV163(ColabCampaignPlanV162):
    """Campaign 1b plan — symmetric binding + explicit constraint rules.

    Beyond V162:
      * model_digest / tokenizer_digest / generation_template_digest are
        bound at plan-signing time (computed from the loaded tokenizer +
        model config BEFORE any generation — signing still precedes any
        evaluation), making A/B arms evidence-symmetric at the identity
        layer.
      * Security is an explicit dual rule: absolute floor
        security_min_pass_rate AND relative regression bound
        security_max_drop_vs_L1 (Security(L6) - Security(L1) >= -eps).
      * Retention is a regression bound vs L1 (retention_max_drop),
        replacing the miscalibrated absolute floor.
      * Confidence criterion: min_seeds_positive_ft seeds must show
        strictly positive delta_ft_neural, plus the mean bound.
    """
    model_digest: str = ""
    tokenizer_digest: str = ""
    generation_template_digest: str = ""
    retention_max_drop: float = 0.10
    security_min_pass_rate: float = 0.5
    security_max_drop_vs_L1: float = 0.10
    min_seeds_positive_ft: int = 4
    schema: str = "mini-agi-v16.3-colab-campaign-plan-v1"

    def __post_init__(self):
        super().__post_init__()
        for x in (self.model_digest, self.tokenizer_digest,
                  self.generation_template_digest):
            validate_digest(x)
        if not 0 <= self.security_min_pass_rate <= 1:
            raise ValueError("security_min_pass_rate must be in [0,1]")
        if self.security_max_drop_vs_L1 < 0 or self.retention_max_drop < 0:
            raise ValueError("regression bounds must be non-negative")
        if not 0 < self.min_seeds_positive_ft <= len(self.seeds):
            raise ValueError("min_seeds_positive_ft must be in (0, n_seeds]")

    @property
    def digest(self) -> str:
        return digest(self)


@dataclass(frozen=True)
class ColabCampaignPlanV164(ColabCampaignPlanV163):
    """Campaign 2 plan — scale/generalization falsification.

    Beyond V163:
      * dataset_path + require_family_disjoint_hidden are bound into the
        signed plan so the qualifier knows which committed corpus to
        recompute the partition from (no filename convention coupling).
      * The primary endpoint adds a distributional criterion: a
        deterministic percentile bootstrap CI over per-seed
        delta_ft_neural whose lower bound must exceed
        min_delta_ft_ci_lower — not just same-sign seeds.
      * delayed_retention_max_drop constrains the seed-end persistence
        probes (L1_delayed/L6_delayed cells): retention re-measured on
        the reloaded persisted artifact after the seed's full arm
        sequence.
      * Efficiency reporting is preregistered (train/eval seconds and
        trainable-parameter counts travel inside receipts; derived
        transfer-per-hour / transfer-per-parameter appear in RESULT).
    """
    dataset_path: str = "configs/campaign2_tasks.jsonl"
    require_family_disjoint_hidden: bool = True
    bootstrap_resamples: int = 20000
    ci_alpha: float = 0.05
    min_delta_ft_ci_lower: float = 0.0
    delayed_retention_max_drop: float = 0.10
    schema: str = "mini-agi-v16.4-colab-campaign-plan-v1"

    def __post_init__(self):
        super().__post_init__()
        if not self.dataset_path or ".." in Path(self.dataset_path).parts:
            raise ValueError("dataset_path must be a repo-relative path")
        if self.bootstrap_resamples < 1000:
            raise ValueError("bootstrap_resamples must be >= 1000")
        if not 0 < self.ci_alpha < 0.5:
            raise ValueError("ci_alpha must be in (0, 0.5)")
        if self.delayed_retention_max_drop < 0:
            raise ValueError("delayed_retention_max_drop must be non-negative")

    @property
    def digest(self) -> str:
        return digest(self)


@dataclass(frozen=True)
class ColabCampaignPlanV165(ColabCampaignPlanV164):
    """Campaign plan v16.5 — full experiment binding.

    Beyond V164:
      * experiment_protocol_digest binds an ExperimentProtocolV1 covering
        every learning, memory/replay, and generation hyperparameter.
        Nothing experiment-affecting may live outside the signed surface.
      * model_digest / tokenizer_digest are PHYSICAL artifact digests
        (sha256 over the resolved model snapshot directory / tokenizer
        artifact files, with HF cache symlinks resolved to their blob
        targets), replacing the semantic config-digest identity used by
        V163/V164 plans. A modified local weight file masquerading under
        a pinned revision is now detectable.

    V164 remains the schema of the executed Campaign 2 evidence; V165 is
    the binding surface for new campaigns (Campaign 3 onward).
    """
    experiment_protocol_digest: str = ""
    schema: str = "mini-agi-v16.5-colab-campaign-plan-v1"

    def __post_init__(self):
        super().__post_init__()
        validate_digest(self.experiment_protocol_digest)


@dataclass(frozen=True)
class ColabCampaignPlanV166(ColabCampaignPlanV165):
    """Campaign plan v16.6 — Phase-6 scientific benchmark surface.

    Beyond V165:
      * final_holdout_digest binds an evaluator-sealed partition the
        worker never sees — excluded from training, model selection,
        prompt tuning, and feedback. Post-qualification confirmation
        runs against it under the evaluation authority.
      * cluster_unit declares the uncertainty unit (default "family"):
        qualification CIs are computed by resampling clusters, not
        rows — correlated same-template examples are not treated as
        independent evidence.
      * max_false_activation_rate gates spurious firing: rows where L1
        answered correctly but the adapted arm changed the output to an
        incorrect one. 1.0 = measured-but-not-gated (default);
        preregistered campaigns should set a real bound.
      * n_comparisons_preregistered records the declared number of
        confirmatory comparisons — the multiplicity budget is signed.
    """
    final_holdout_digest: str = ""
    cluster_unit: str = "family"
    max_false_activation_rate: float = 1.0
    n_comparisons_preregistered: int = 1
    # Native serving tier the qualified adapter must satisfy: 1 =
    # NativeAdapter1 (LM head only), 2 = NativeAdapter2 (v2 bundle,
    # attention projections). Bound in the signed plan so the runner's
    # servability gate and the compiler claim the same tier.
    native_adapter_tier: int = 1
    schema: str = "mini-agi-v16.6-colab-campaign-plan-v1"

    def __post_init__(self):
        super().__post_init__()
        validate_digest(self.final_holdout_digest)
        if self.cluster_unit not in ("family", "seed", "none"):
            raise ValueError("cluster_unit must be family|seed|none")
        if not 0 <= self.max_false_activation_rate <= 1:
            raise ValueError("max_false_activation_rate must be in [0,1]")
        if self.n_comparisons_preregistered < 1:
            raise ValueError("n_comparisons_preregistered must be >= 1")
        if self.native_adapter_tier not in (1, 2):
            raise ValueError("native_adapter_tier must be 1 or 2")
