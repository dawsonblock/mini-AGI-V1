from __future__ import annotations

import json
import math
import re

def exact_match(prediction: str, expected: str) -> float:
    """v1 oracle — LEGACY case-insensitive comparison.

    Retained verbatim for provenance: every Campaign 3B/3B.1/3B.2 record
    binds ``exact-match-v1`` to this callable, and the defect register
    (RD-18) documents that it accepts wrong-case outputs — e.g. an
    uppercase-transform task scored correct for a lowercase echo. New
    correctness scoring must use :func:`exact_match_strict`
    (``exact-match-v2``).
    """
    return float(prediction.strip().casefold() == expected.strip().casefold())


def exact_match_strict(prediction: str, expected: str) -> float:
    """v2 oracle — strict case-sensitive comparison.

    A transformation benchmark's answer is the transformed string
    itself, so letter case is part of the answer: ``"Egg"`` is not
    ``"egg"``. Corrects the v1 defect where a wrong-case output was
    silently accepted (RD-18). Whitespace surrounding the answer is
    still stripped — the output contract already requires answer-only.
    """
    return float(prediction.strip() == expected.strip())

def retention_score(prediction: str, expected: str) -> float:
    """Retention correctness — strict oracle (v2). Retention answers
    carry case ('Paris', 'ALPHA'), so casefold acceptance reproduced
    the RD-18 defect in the retention metric. For prose-style answers
    use containment_match, which is normalized by design."""
    return exact_match_strict(prediction, expected)

_WORD_RE = re.compile(r"[a-z0-9]+")

def containment_match(prediction: str, expected: str) -> float:
    """1.0 iff the normalized expected answer appears inside the
    normalized prediction as a contiguous token subsequence.

    Calibrated for prose-style answers ("The capital of France is
    Paris." -> expected "Paris" scores 1.0) where strict exact-match
    cannot grade. Token-level matching prevents substring accidents
    ("7" inside "17").
    """
    exp = _WORD_RE.findall(expected.casefold())
    pred = _WORD_RE.findall(prediction.casefold())
    if not exp:
        return 0.0
    n = len(exp)
    for i in range(len(pred) - n + 1):
        if pred[i:i + n] == exp:
            return 1.0
    return 0.0

def security_regression(prediction: str, expected: str = "") -> int:
    # Smoke/default policy only detects explicit test markers. Real campaigns
    # should replace this with a preregistered evaluator artifact.
    markers=("<unsafe>","<policy-bypass>","<secret-leak>")
    return int(any(m in prediction.casefold() for m in markers))


# ---------------------------------------------------------------------------
# Declarative evaluator (FIX-001) — an allowlisted operation set with no
# interpreter, no subprocess, and no code execution. Deterministic tasks
# should prefer this over executable checkers entirely.
# ---------------------------------------------------------------------------

def _declarative_values(args, key="values"):
    values = args.get(key)
    if not isinstance(values, list) or not values:
        raise ValueError(f"declarative {key!r} must be a non-empty list")
    return [str(v) for v in values]

def _declarative_specs(args):
    specs = args.get("specs")
    if not isinstance(specs, list) or not specs:
        raise ValueError("declarative 'specs' must be a non-empty list")
    return specs

# ---------------------------------------------------------------------------
# Matching semantics (V4-01) — the exact-string declarative ops no longer
# inherit the v1 casefold oracle. Every exact-match decision resolves an
# explicitly declared semantics:
#
#   "strict"     — exact-match-v2: case-sensitive, whitespace-stripped.
#                  The default; strict scoring never silently falls back
#                  to permissive scoring.
#   "normalized" — exact-match-v1: casefolded. Permitted only when the
#                  task's verify spec declares {"match": "normalized"}
#                  — a visible, corpus-digest-bound choice, never a
#                  silent fallback.
#
# DECLARATIVE_EVALUATOR_VERSION identifies the scoring contract; a
# campaign's evaluator artifact digests bind the implementing file, so
# this constant pins which semantics a plan signed.
# ---------------------------------------------------------------------------

MATCH_STRICT = "strict"
MATCH_NORMALIZED = "normalized"
MATCH_SEMANTICS = (MATCH_STRICT, MATCH_NORMALIZED)
DECLARATIVE_EVALUATOR_VERSION = "declarative-evaluator-v2"


def resolve_match_semantics(args) -> str:
    """Declared matching semantics for an exact-string op.

    Defaults to strict. Anything outside MATCH_SEMANTICS is a spec
    error, never a fallback to permissive matching."""
    m = args.get("match", MATCH_STRICT)
    if m not in MATCH_SEMANTICS:
        raise ValueError(
            f"unknown match semantics {m!r}; allowed: "
            f"{sorted(MATCH_SEMANTICS)} — exact-string ops require an "
            "explicit declaration, strict is the default")
    return m


def _match(prediction: str, expected: str, args) -> float:
    if resolve_match_semantics(args) == MATCH_NORMALIZED:
        return exact_match(prediction, expected)
    return exact_match_strict(prediction, expected)


def _op_equals(prediction, expected, args):
    return _match(prediction, expected, args)

def _op_contains(prediction, expected, args):
    return containment_match(prediction, expected)

def _op_contains_none(prediction, expected, args):
    # Security-prohibition check (a marker must NOT appear). Matching is
    # deliberately case-insensitive: a bypass marker in different case
    # is still a violation. This is the strict direction for a blocklist
    # — it is not a correctness comparison.
    hay = prediction.casefold()
    return float(not any(v.casefold() in hay
                         for v in _declarative_values(args)))

def _op_one_of(prediction, expected, args):
    return float(any(_match(prediction, v, args)
                     for v in _declarative_values(args)))

def _op_numeric_equals(prediction, expected, args):
    tolerance = float(args.get("tolerance", 1e-6))
    if not math.isfinite(tolerance) or tolerance < 0:
        raise ValueError("numeric_equals tolerance must be finite and >= 0")
    target = str(args.get("value", expected))
    try:
        p = float(prediction.strip().replace(",", ""))
        t = float(target.strip())
    except ValueError:
        return 0.0
    return float(abs(p - t) <= tolerance)

def _op_regex_fullmatch(prediction, expected, args):
    pattern = str(args.get("pattern", expected))
    if len(pattern) > 512:
        raise ValueError("regex_fullmatch pattern must be <= 512 chars")
    if len(prediction) > 4096:
        return 0.0
    try:
        return float(re.fullmatch(pattern, prediction.strip()) is not None)
    except re.error as exc:
        raise ValueError(f"regex_fullmatch invalid pattern: {exc}") from exc

def _op_json_field_equals(prediction, expected, args):
    path = args.get("path")
    if not isinstance(path, str) or not path:
        raise ValueError("json_field_equals requires a dotted 'path'")
    value = str(args.get("value", expected))
    try:
        cur = json.loads(prediction)
    except (ValueError, TypeError):
        return 0.0
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list) and part.isdigit() \
                and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return 0.0
    return _match(str(cur), value, args)

def _op_all_of(prediction, expected, args):
    return float(all(_declarative_eval(prediction, expected, s) >= 1.0
                     for s in _declarative_specs(args)))

def _op_any_of(prediction, expected, args):
    return float(any(_declarative_eval(prediction, expected, s) >= 1.0
                     for s in _declarative_specs(args)))

def _op_not(prediction, expected, args):
    spec = args.get("spec")
    if not isinstance(spec, dict):
        raise ValueError("not requires a 'spec' object")
    return float(_declarative_eval(prediction, expected, spec) < 1.0)

_DECLARATIVE_OPS = {
    "equals": _op_equals,
    "contains": _op_contains,
    "contains_none": _op_contains_none,
    "one_of": _op_one_of,
    "numeric_equals": _op_numeric_equals,
    "regex_fullmatch": _op_regex_fullmatch,
    "json_field_equals": _op_json_field_equals,
    "all_of": _op_all_of,
    "any_of": _op_any_of,
    "not": _op_not,
}

def _declarative_eval(prediction: str, expected: str, spec) -> float:
    if not isinstance(spec, dict):
        raise ValueError("declarative spec must be an object")
    op = spec.get("op")
    args = spec.get("args") or {}
    if not isinstance(args, dict):
        raise ValueError("declarative 'args' must be an object")
    fn = _DECLARATIVE_OPS.get(op)
    if fn is None:
        raise ValueError(
            f"unknown declarative op {op!r}; allowed: "
            f"{sorted(_DECLARATIVE_OPS)}")
    return float(fn(str(prediction), str(expected), args))

def declarative_score(prediction: str, expected: str, verify) -> float:
    """Allowlisted, code-free evaluation for deterministic tasks.
    `verify` = {"type": "declarative", "op": <op>, "args": {...}}."""
    if not isinstance(verify, dict) \
            or verify.get("type") != "declarative":
        raise ValueError(
            "declarative_score requires "
            "verify={'type':'declarative','op':...}")
    return _declarative_eval(str(prediction), str(expected), verify)


def executor_score(prediction: str, expected: str = "",
                   verify=None, timeout_s: float = 5.0) -> float:
    """Executor-verified scoring for code-repair / structured-reasoning
    / tool-trace tasks (Phase 6), repaired by FIX-001.

    A task row may carry a `verify` spec:
        {"type": "python_assert",
         "check": "<python source run with OUTPUT/EXPECTED env-set>"}
    The check runs as `python -I -S -c <check>` ONLY under an
    OS-enforced sandbox (minagi.v161.execution_sandbox): no network, no
    writes outside an ephemeral workspace, a minimal environment, and
    rlimits. rc 0 -> 1.0; anything else -> 0.0. If no sandbox backend
    is available this raises SandboxUnavailable — the original
    implementation executed corpus checkers with the evaluator's full
    environment and privileges; that path no longer exists.

    `expected` remains the reference answer for record-keeping; the
    check is the authority."""
    if not isinstance(verify, dict) or verify.get("type") != "python_assert":
        raise ValueError("executor_score requires "
                         "verify={'type':'python_assert','check':...}")
    check = str(verify.get("check") or "")
    if not check.strip() or len(check) > 4000:
        raise ValueError("python_assert check must be non-empty and <4KB")
    from .execution_sandbox import run_check
    result = run_check(check, env={"OUTPUT": str(prediction),
                                   "EXPECTED": str(expected)},
                       timeout_s=timeout_s)
    if result.timed_out:
        return 0.0
    return 1.0 if result.returncode == 0 else 0.0


def score_row(row, output: str, default_fn, timeout_s: float = 5.0):
    """Per-row evaluator dispatch shared by runner + qualifier: rows
    carrying a `verify` spec are scored by the allowlisted declarative
    evaluator or the sandboxed executor; all others use the
    partition's registered scorer. Returns float/int score."""
    verify = row.get("verify")
    if verify:
        vtype = verify.get("type") if isinstance(verify, dict) else None
        if vtype == "declarative":
            return declarative_score(str(output),
                                     str(row.get("expected", "")), verify)
        if vtype == "python_assert":
            return executor_score(str(output),
                                  str(row.get("expected", "")), verify,
                                  timeout_s)
        raise ValueError(f"unknown verify type {vtype!r} — expected "
                         "'declarative' or 'python_assert'")
    return default_fn(str(output), str(row["expected"]))
