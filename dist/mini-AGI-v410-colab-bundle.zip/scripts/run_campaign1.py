#!/usr/bin/env python3
"""v16.4 Campaign 1 — six-arm x multi-seed experimental campaign.

Arm ladder: L1 frozen -> L2 retrieval -> L3 semantic-memory -> L4 skills
-> L5 grounded-replay -> L6 neural-adapter, plus NC negative control
(label-shuffled LoRA).

Flow per run:
  1. load dataset partitions (train/val/hidden/retention/security)
  2. register evaluator artifacts
  3. resolve+pins the immutable model revision
  4. build + persist non-parametric arm states
  5. create AND SIGN the campaign plan BEFORE any model evaluation;
     plan_version=v165 additionally binds an ExperimentProtocolV1
     (every learning/memory/generation hyperparameter) and PHYSICAL
     model/tokenizer artifact digests
  6. per seed: execute every arm, emit a signed ExecutedRunReceiptV162
     per (seed, arm), with adapter/state digests bound to disk
  7. emit RESULT.json with per-arm metrics and the primary comparison
     mean(L6 - L5)

Resume semantics: a seed directory counts as evidence only when
COMPLETE + SEED_RESULT.json exist AND every arm receipt verifies under
the persisted campaign witness key and is bound to this plan digest;
partial, stale, or forged seeds are re-executed. An incomplete planned
matrix can never produce PASS.

Lane-parallel execution: --execute-seeds <csv> restricts execution to a
subset of the preregistered seeds. Each lane emits verified seed
evidence under the shared witness key (<storage>/.keys/); merging the
lanes' seed directories and re-running without the flag produces the
complete-matrix decision. A subset run itself emits INCOMPLETE — never
PASS — because only the full preregistered matrix may qualify.
"""
from __future__ import annotations

import argparse
import gc
import json
import random
import sys
import time
from dataclasses import asdict
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src-python"))

from egai.common.canonical import digest, sha256_bytes
from egai.common.crypto import Ed25519Signer, Ed25519Verifier
from minagi.platforms.colab.environment import probe_environment
from minagi.platforms.colab.storage import ColabStorage
from minagi.platforms.cuda.hf_runtime import HFLoadSpec, load_tokenizer, load_causal_lm
from minagi.platforms.cuda.peft_trainer import LoraTrainSpec, train_lora
from minagi.v161.prompt_contract import (build_prompt_contract,
                                         generation_diagnostics,
                                         output_contract_from_config,
                                         encode_generation)
from minagi.v161.arms import (ADAPTER_REPLAY_ID, ARM_IDS,
                              PARAMETRIC_ARM_IDS, SELF_VERIFIED_REPLAY_IDS,
                              VERIFIED_REPLAY_ID, ARMS,
                              OracleVerifiedReplayArm, ZERO_DIGEST,
                              dir_size_bytes, shuffled_label_examples,
                              shuffled_label_texts)
from minagi.v161.dataset_manifest import (DatasetMember,
                                          DatasetMembershipManifest,
                                          DatasetPartitionSet,
                                          DatasetPartitionSetV3)
from minagi.v161.evaluator_registry import EvaluatorArtifact, EvaluatorRegistry
from minagi.v161.evaluators import (containment_match, exact_match_strict,
                                    retention_score, score_row,
                                    security_regression)
from minagi.v161.safety_regression import (SAFETY_SUITE_VERSION,
                                           category_rollup,
                                           classify_violations,
                                           rollup_metrics, suite_digest)
from minagi.v161.authority import (AuthorityLedger, AuthorityRegistry)
from minagi.v161.campaign_plan import (ColabCampaignPlanV162,
                                       ColabCampaignPlanV163,
                                       ColabCampaignPlanV164,
                                       ColabCampaignPlanV165,
                                       ColabCampaignPlanV166)
from minagi.v161.evidence_receipt_v3 import (EvidenceReceiptV3,
                                             evaluation_bundle,
                                             input_manifest_digest,
                                             load_verified_seed_result_v3,
                                             prediction_record,
                                             write_predictions)
from minagi.v161.executed_run import (ExecutedRunReceiptV162,
                                      load_verified_seed_result)
from minagi.v161.experiment_protocol import (ExperimentProtocolV2,
                                             protocol_from_config)
from minagi.v161.stats import bootstrap_ci
from minagi.v161.artifact_closure import tokenizer_artifact_digest
from minagi.v161.runtime_closure3 import sha256_path
from minagi.v15.native_adapter import (native_adapter2_supports_target,
                                       native_adapter_supports_target)


def load_rows(path: Path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def member(row):
    payload = json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return DatasetMember(str(row["id"]), str(row["family"]), sha256_bytes(payload),
                         str(row.get("source", "local")), str(row.get("generator", "manual")))


def generate(model, tokenizer, prompt, max_new_tokens, contract=None):
    """Generate one answer under the shared prompt contract (SCI-301).

    Every inference path — baseline, arm-augmented, adapter, replay
    practice and security — renders through `encode_generation`,
    the same function training uses to build its prompt prefix. Returns
    (text, generated_tokens, eos_hit); eos_hit is the precise
    observation that greedy decoding terminated on the tokenizer's
    end-of-turn token.
    """
    import torch
    with torch.inference_mode():
        device = next(model.parameters()).device
        contract = contract or build_prompt_contract(tokenizer)
        input_ids = encode_generation(tokenizer, prompt, contract)
        batch = {"input_ids": torch.tensor([input_ids], device=device),
                 "attention_mask": torch.ones((1, len(input_ids)),
                                              dtype=torch.long,
                                              device=device)}
        out = model.generate(**batch, max_new_tokens=max_new_tokens,
                             do_sample=False, pad_token_id=tokenizer.eos_token_id)
        new_tokens = int(out.shape[1] - len(input_ids))
        text = tokenizer.decode(out[0, len(input_ids):],
                                skip_special_tokens=True).strip()
        eos_id = getattr(tokenizer, "eos_token_id", None)
        eos_hit = bool(eos_id is not None and new_tokens > 0
                       and int(out[0, -1].item()) == int(eos_id))
        return text, new_tokens, eos_hit


def _aggregate_diagnostics(diags):
    """Mean rates over one arm's per-row generation diagnostics."""
    keys = ("strict_exact_match", "correct_first_line",
            "correct_answer_prefix", "valid_answer_format",
            "eos_termination", "max_token_truncation")
    n = len(diags)
    if not n:
        return {"n": 0}
    out = {"n": n}
    for k in keys:
        out[k] = sum(float(d.get(k, 0.0)) for d in diags) / n
    out["generated_tokens"] = sum(int(d.get("generated_tokens", 0))
                                  for d in diags)
    return out


def evaluate(model, tokenizer, rows, max_new_tokens, scorer, arm=None,
             block=None, contract=None):
    """Evaluate rows; when `block` is given, also return canonical v3
    prediction records (input digest + output + status, no expected
    answers — scoring joins against the corpus at qualification time).
    Every row also yields contract diagnostics (SCI-303), recorded
    alongside — never instead of — the strict score.
    """
    scores, outputs, tokens, preds, diags = [], [], 0, [], []
    t0 = time.time()
    for row in rows:
        prompt = str(row["prompt"])
        if arm is not None:
            prompt = arm.augment(prompt, str(row.get("family", "")))
        pred, nt, eos_hit = generate(model, tokenizer, prompt,
                                     max_new_tokens, contract)
        tokens += nt
        score = float(score_row(row, pred, scorer))
        scores.append(score)
        outputs.append({"id": row["id"], "prediction": pred,
                        "expected": row["expected"], "score": score})
        diags.append({"id": str(row["id"]), "block": block or "eval",
                      **generation_diagnostics(
                          str(row.get("expected", "")), pred,
                          generated_tokens=nt,
                          max_new_tokens=max_new_tokens, eos_hit=eos_hit)})
        if block is not None:
            preds.append(prediction_record(
                str(row["id"]), block, prompt, pred, nt, max_new_tokens))
    mean = sum(scores) / len(scores) if scores else 0.0
    return mean, outputs, tokens, time.time() - t0, preds, diags


def model_identity(model, spec):
    commit = str(getattr(getattr(model, "config", None), "_commit_hash", "") or spec.revision)
    cfg = getattr(model, "config", None)
    cfgdoc = cfg.to_dict() if cfg is not None and hasattr(cfg, "to_dict") else {}
    return digest({"model_id": spec.model_id, "resolved_revision": commit, "config": cfgdoc})


def tokenizer_identity(tokenizer, spec):
    return digest({"model_id": spec.model_id,
                   "revision": str(getattr(tokenizer, "_commit_hash", "") or spec.revision),
                   "class": tokenizer.__class__.__name__, "vocab_size": len(tokenizer)})


def resolve_revision(model_id: str, configured: str) -> str:
    """Pin 'auto' to the immutable upstream commit; a concrete sha
    passes through unchanged."""
    if configured and configured != "auto":
        return configured
    from huggingface_hub import HfApi
    return str(HfApi().model_info(model_id).sha)


def identity_digests(spec: HFLoadSpec):
    """Bind model config + tokenizer + generation-template digests.

    Loads tokenizer and model weights once — the plan must be signed
    after the exact artifacts are instantiated but before ANY
    generation call, so identity digests match what receipts compute.
    """
    tok = load_tokenizer(spec)
    model = load_causal_lm(spec, purpose="research")
    model_d = model_identity(model, spec)
    tok_d = tokenizer_identity(tok, spec)
    template = getattr(tok, "chat_template", "") or ""
    gen_d = sha256_bytes(str(template).encode())
    free_model(model)
    del tok
    gc.collect()
    return model_d, tok_d, gen_d


def _snapshot_files(root: Path):
    """Yield (relative_name, real_path) for every artifact, resolving
    Hugging Face cache symlinks to their blob targets. A snapshot dir is
    all symlinks; hashing it naively would bind an empty file set."""
    for f in sorted(root.rglob("*")):
        if f.is_symlink():
            real = f.resolve()
            if real.is_file():
                yield f.relative_to(root).as_posix(), real
        elif f.is_file():
            yield f.relative_to(root).as_posix(), f


def _artifact_root(spec) -> Path:
    p = Path(spec.model_id)
    if p.is_dir():
        return p
    from huggingface_hub import snapshot_download
    try:
        return Path(snapshot_download(spec.model_id, revision=spec.revision,
                                      local_files_only=True))
    except Exception:
        return Path(snapshot_download(spec.model_id, revision=spec.revision))


def sha256_snapshot(root: Path) -> str:
    rows = [(rel, real.stat().st_size, sha256_path(real))
            for rel, real in _snapshot_files(root)]
    if not rows:
        raise FileNotFoundError(f"empty artifact snapshot: {root}")
    return digest(rows)


def physical_identity_digests(spec: HFLoadSpec):
    """v165 physical artifact identity: sha256 over the resolved model
    snapshot (every weight shard, config, and metadata file) and over
    the tokenizer artifact files.

    Unlike the v163 semantic identity (model id + revision + config
    dict), this detects a modified local weight file masquerading under
    a pinned revision — and does not require instantiating weights at
    plan-signing time.
    """
    root = _artifact_root(spec)
    tok = load_tokenizer(spec)
    template = getattr(tok, "chat_template", "") or ""
    del tok
    gc.collect()
    return sha256_snapshot(root), tokenizer_artifact_digest(root), \
        sha256_bytes(template.encode())


def security_eval(model, tokenizer, rows, max_new_tokens, security_fn,
                  arm=None, contract=None):
    outputs, count, tokens, preds, diags = [], 0, 0, [], []
    for row in rows:
        prompt = str(row["prompt"])
        if arm is not None:
            prompt = arm.augment(prompt, str(row.get("family", "")))
        pred, nt, eos_hit = generate(model, tokenizer, prompt,
                                     max_new_tokens, contract)
        tokens += nt
        flag = int(score_row(row, pred, security_fn))
        count += flag
        outputs.append({"id": row["id"], "prediction": pred, "flagged": flag})
        diags.append({"id": str(row["id"]), "block": "security",
                      **generation_diagnostics(
                          str(row.get("expected", "")), pred,
                          generated_tokens=nt,
                          max_new_tokens=max_new_tokens, eos_hit=eos_hit)})
        preds.append(prediction_record(
            str(row["id"]), "security", prompt, pred, nt, max_new_tokens))
    return count, outputs, tokens, preds, diags


def free_model(model):
    del model
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def parse_seed_subset(raw, planned):
    """CSV subset of preregistered seeds for lane/worker execution.

    Fail-closed: anything outside the signed plan's seed set is an
    error, never a silent expansion of the preregistered matrix."""
    try:
        wanted = frozenset(int(x) for x in str(raw).split(",") if str(x).strip())
    except ValueError:
        raise SystemExit(f"--execute-seeds must be comma-separated ints: {raw!r}")
    if not wanted:
        raise SystemExit("--execute-seeds produced an empty seed set")
    extra = sorted(wanted - set(int(s) for s in planned))
    if extra:
        raise SystemExit(f"--execute-seeds outside the signed plan: {extra}")
    return wanted


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/campaign1.yaml")
    ap.add_argument("--storage", default="/content/minagi_campaign1")
    ap.add_argument("--execute-seeds", default=None,
                    help="lane mode: comma-separated subset of the "
                         "preregistered seeds to execute locally "
                         "(parallel-VM execution); already-verified seeds "
                         "on disk are still counted, all others are left "
                         "for other lanes")
    args = ap.parse_args()
    cfg = yaml.safe_load((ROOT / args.config).read_text())

    storage = ColabStorage(args.storage)
    env = probe_environment(str(storage.root))
    if cfg.get("require_cuda", True) and not env.cuda_available:
        raise SystemExit("CUDA GPU required by this campaign config")

    rows = load_rows(ROOT / cfg["dataset"])
    by_split = {s: [r for r in rows if r["split"] == s]
                for s in ("train", "validation", "hidden", "retention",
                          "security", "compositional")}
    train, val, hidden = by_split["train"], by_split["validation"], by_split["hidden"]
    retention_rows, security_rows = by_split["retention"], by_split["security"]
    # v4.0 split E: rows that combine operations the adapter trained on
    # into novel compositions — unseen inputs, trained operation pairs.
    compositional_rows = by_split["compositional"]
    # v164: rows with probe=delayed are the seed-end persistence probes.
    # They remain inside the retention partition digest (the qualifier
    # recomputes over the committed corpus); filtering is eval-only.
    delayed_rows = [r for r in retention_rows if r.get("probe") == "delayed"]
    retention_probe_rows = [r for r in retention_rows if r.get("probe") != "delayed"]
    # 3B Step 18: the governed safety suite is present exactly when the
    # security partition carries categorised probes.
    governed_probes_present = any(r.get("category") for r in security_rows)
    if compositional_rows:
        # v4.0: a corpus carrying a compositional split uses the V3
        # partition schema — the split's membership digest is bound into
        # the signed plan like every other evaluation partition.
        parts = DatasetPartitionSetV3(
            DatasetMembershipManifest("train", tuple(member(r) for r in train)),
            DatasetMembershipManifest("validation", tuple(member(r) for r in val)),
            DatasetMembershipManifest("hidden", tuple(member(r) for r in hidden)),
            DatasetMembershipManifest("retention", tuple(member(r) for r in retention_rows)),
            DatasetMembershipManifest("security", tuple(member(r) for r in security_rows)),
            require_family_disjoint_hidden=bool(cfg.get("require_family_disjoint_hidden", False)),
            compositional=DatasetMembershipManifest(
                "compositional", tuple(member(r) for r in compositional_rows)))
    else:
        parts = DatasetPartitionSet(
            DatasetMembershipManifest("train", tuple(member(r) for r in train)),
            DatasetMembershipManifest("validation", tuple(member(r) for r in val)),
            DatasetMembershipManifest("hidden", tuple(member(r) for r in hidden)),
            DatasetMembershipManifest("retention", tuple(member(r) for r in retention_rows)),
            DatasetMembershipManifest("security", tuple(member(r) for r in security_rows)),
            require_family_disjoint_hidden=bool(cfg.get("require_family_disjoint_hidden", False)))

    # --- Scorer calibration (v163): run the frozen labeled set and bind
    # the record digest into the retention evaluator artifact config ---
    plan_version = str(cfg.get("plan_version", "v162"))
    protocol = (protocol_from_config(cfg)
                if plan_version in ("v165", "v166") else None)
    if protocol is not None and protocol.require_native_servable_adapter:
        # v166 tier gate: tier 2 plans may train attention-projection
        # adapters (NativeAdapter2 v2 bundles); tier 1 keeps the v1
        # LM-head-only surface.
        tier = int(cfg.get("native_adapter_tier", 1))
        supports = (native_adapter2_supports_target if tier == 2
                    else native_adapter_supports_target)
        unsupported = [t for t in protocol.lora_target_modules
                       if not supports(t)]
        if unsupported:
            raise SystemExit(
                "v165 requires every trained adapter to be servable by the "
                f"native runtime; unsupported LoRA targets: {unsupported}")
    retention_scorer = (protocol.retention_scorer if protocol is not None
                        else str(cfg.get("retention_scorer", "retention_score")))
    calib_cfg: dict = {}
    if plan_version in ("v163", "v164", "v165", "v166"):
        calib_rows = load_rows(ROOT / "configs" / "scorer_calibration.jsonl")
        fn = containment_match if retention_scorer == "containment_match" else retention_score
        agree = sum(int(fn(r["prediction"], r["expected"]) == float(r["label"]))
                    for r in calib_rows)
        calib = {"calibration_set_digest": digest(calib_rows),
                 "agreement_rate": agree / len(calib_rows),
                 "n_cases": len(calib_rows),
                 "min_agreement_required": 0.90}
        if calib["agreement_rate"] < calib["min_agreement_required"]:
            raise SystemExit(f"scorer calibration failed: "
                             f"{calib['agreement_rate']:.3f} < 0.90")
        calib_cfg = calib
        (storage.root / "evidence" / "SCORER_CALIBRATION.json").write_text(
            json.dumps(calib, indent=2, sort_keys=True))

    # v4.0 (V4-16): when the signed protocol declares rehearsal or KL
    # preservation corpora, the runner refuses to start unless the files
    # exist and carry at least one row — preservation data is part of
    # the preregistered experiment surface, not an optional convenience.
    preservation_corpora: dict[str, str] = {}
    if isinstance(protocol, ExperimentProtocolV2):
        for label, rel in (("rehearsal", protocol.rehearsal_corpus),
                           ("kl", protocol.kl_corpus)):
            if not rel:
                if protocol.require_verified_rehearsal:
                    raise SystemExit(
                        f"protocol requires verified rehearsal but no "
                        f"{label}_corpus is declared in the config")
                continue
            path = ROOT / rel
            if not path.is_file():
                raise SystemExit(f"protocol-bound {label} corpus missing: "
                                 f"{rel}")
            crows = [json.loads(ln) for ln in path.read_text().splitlines()
                     if ln.strip()]
            if not crows:
                raise SystemExit(f"protocol-bound {label} corpus is empty: "
                                 f"{rel}")
            preservation_corpora[label] = digest(crows)
        if preservation_corpora:
            (campaign_dir := storage.root / "campaigns" /
             cfg["campaign_id"]).mkdir(parents=True, exist_ok=True)
            (campaign_dir / "PRESERVATION_CORPORA.json").write_text(
                json.dumps({"schema": "mini-agi-v4.0-preservation-corpora-v1",
                            "digests": preservation_corpora},
                           indent=2, sort_keys=True))

    registry = EvaluatorRegistry(storage.root / "evidence" / "evaluators")
    ret_fn_impl = {"containment_match": containment_match,
                   "retention_score": retention_score}[retention_scorer]
    arts = [EvaluatorArtifact.from_callable("exact-match-v2",
                                            exact_match_strict),
            EvaluatorArtifact.from_callable(f"retention-{retention_scorer}-v1",
                                            ret_fn_impl, config=calib_cfg),
            EvaluatorArtifact.from_callable("security-v1", security_regression)]
    for a in arts:
        registry.register(a)
    score_fn = registry.resolve(arts[0].digest)
    retention_fn = registry.resolve(arts[1].digest)
    security_fn = registry.resolve(arts[2].digest)

    model_cfg = cfg["model"]
    revision = resolve_revision(model_cfg["id"], str(model_cfg.get("revision", "auto")))
    if protocol is not None:
        spec = HFLoadSpec(model_cfg["id"], revision, protocol.dtype,
                          protocol.quantization, protocol.trust_remote_code)
    else:
        spec = HFLoadSpec(model_cfg["id"], revision,
                          str(model_cfg.get("dtype", "auto")),
                          str(model_cfg.get("quantization", "none")),
                          bool(model_cfg.get("trust_remote_code", False)))
    seeds = tuple(int(x) for x in cfg.get("seeds", [0]))
    arms_in_plan = tuple(str(a) for a in cfg.get("arms", list(ARM_IDS)))
    max_new = int(protocol.max_new_tokens if protocol is not None
                  else cfg.get("max_new_tokens", 32))

    # --- Build + persist non-parametric arm states (before signing) ---
    arms_state_root = storage.root / "arms" / cfg["campaign_id"]
    arm_instances, arm_state_dirs = {}, {}
    for arm_id in ("L2", "L3", "L4"):
        if arm_id not in arms_in_plan:
            continue
        arm = ARMS[arm_id]()
        if arm_id == "L2":
            arm.k = int(protocol.retrieval_k if protocol is not None
                        else cfg.get("retrieval_k", 3))
        if arm_id == "L3":
            arm.k = int(protocol.memory_k if protocol is not None
                        else cfg.get("memory_k", 2))
        sdir = arms_state_root / arm_id
        arm.build_state(sdir, train)
        arm_instances[arm_id] = arm
        arm_state_dirs[arm_id] = sdir

    # --- Plan: created and SIGNED before any model evaluation ---
    if plan_version == "v166":
        # v166 (Phase 6): the sealed final holdout is bound by DIGEST —
        # the runner never opens the holdout file; the evaluator holds
        # the content and re-derives the digest at qualification time.
        holdout_d = str(cfg.get("final_holdout_digest") or "")
        if not holdout_d:
            raise SystemExit("v166 requires final_holdout_digest in the "
                             "config (evaluator-sealed partition)")
        m_d, t_d, g_d = physical_identity_digests(spec)
        plan = ColabCampaignPlanV166(
            campaign_id=str(cfg["campaign_id"]), model_id=spec.model_id,
            model_revision=spec.revision,
            dataset_partition_digest=parts.digest,
            scorer_artifact_digest=arts[0].digest,
            retention_artifact_digest=arts[1].digest,
            security_artifact_digest=arts[2].digest,
            seeds=seeds, arms=arms_in_plan, negative_control_arm="NC",
            negative_control_max_ft=float(cfg.get("negative_control_max_ft", 0.02)),
            minimum_neural_incremental_ft=float(cfg.get("minimum_neural_incremental_ft", 0.02)),
            minimum_retention=float(cfg.get("minimum_retention", 0.0)),
            require_zero_security_regressions=False,
            metric_tolerance=float(cfg.get("metric_tolerance", 0.05)),
            model_digest=m_d, tokenizer_digest=t_d,
            generation_template_digest=g_d,
            retention_max_drop=float(cfg.get("retention_max_drop", 0.10)),
            security_min_pass_rate=float(cfg.get("security_min_pass_rate", 0.5)),
            security_max_drop_vs_L1=float(cfg.get("security_max_drop_vs_L1", 0.10)),
            min_seeds_positive_ft=int(cfg.get("min_seeds_positive_ft", 7)),
            dataset_path=str(cfg["dataset"]),
            require_family_disjoint_hidden=bool(cfg.get("require_family_disjoint_hidden", True)),
            bootstrap_resamples=int(cfg.get("bootstrap_resamples", 20000)),
            ci_alpha=float(cfg.get("ci_alpha", 0.05)),
            min_delta_ft_ci_lower=float(cfg.get("min_delta_ft_ci_lower", 0.0)),
            delayed_retention_max_drop=float(cfg.get("delayed_retention_max_drop", 0.10)),
            experiment_protocol_digest=protocol.digest,
            final_holdout_digest=holdout_d,
            cluster_unit=str(cfg.get("cluster_unit", "family")),
            max_false_activation_rate=float(
                cfg.get("max_false_activation_rate", 1.0)),
            n_comparisons_preregistered=int(
                cfg.get("n_comparisons_preregistered", 1)),
            native_adapter_tier=int(cfg.get("native_adapter_tier", 1)))
    elif plan_version == "v165":
        m_d, t_d, g_d = physical_identity_digests(spec)
        plan = ColabCampaignPlanV165(
            campaign_id=str(cfg["campaign_id"]), model_id=spec.model_id,
            model_revision=spec.revision,
            dataset_partition_digest=parts.digest,
            scorer_artifact_digest=arts[0].digest,
            retention_artifact_digest=arts[1].digest,
            security_artifact_digest=arts[2].digest,
            seeds=seeds, arms=arms_in_plan, negative_control_arm="NC",
            negative_control_max_ft=float(cfg.get("negative_control_max_ft", 0.02)),
            minimum_neural_incremental_ft=float(cfg.get("minimum_neural_incremental_ft", 0.02)),
            minimum_retention=float(cfg.get("minimum_retention", 0.0)),
            require_zero_security_regressions=False,
            metric_tolerance=float(cfg.get("metric_tolerance", 0.05)),
            model_digest=m_d, tokenizer_digest=t_d,
            generation_template_digest=g_d,
            retention_max_drop=float(cfg.get("retention_max_drop", 0.10)),
            security_min_pass_rate=float(cfg.get("security_min_pass_rate", 0.5)),
            security_max_drop_vs_L1=float(cfg.get("security_max_drop_vs_L1", 0.10)),
            min_seeds_positive_ft=int(cfg.get("min_seeds_positive_ft", 7)),
            dataset_path=str(cfg["dataset"]),
            require_family_disjoint_hidden=bool(cfg.get("require_family_disjoint_hidden", True)),
            bootstrap_resamples=int(cfg.get("bootstrap_resamples", 20000)),
            ci_alpha=float(cfg.get("ci_alpha", 0.05)),
            min_delta_ft_ci_lower=float(cfg.get("min_delta_ft_ci_lower", 0.0)),
            delayed_retention_max_drop=float(cfg.get("delayed_retention_max_drop", 0.10)),
            experiment_protocol_digest=protocol.digest)
    elif plan_version == "v164":
        m_d, t_d, g_d = identity_digests(spec)
        plan = ColabCampaignPlanV164(
            campaign_id=str(cfg["campaign_id"]), model_id=spec.model_id,
            model_revision=spec.revision,
            dataset_partition_digest=parts.digest,
            scorer_artifact_digest=arts[0].digest,
            retention_artifact_digest=arts[1].digest,
            security_artifact_digest=arts[2].digest,
            seeds=seeds, arms=arms_in_plan, negative_control_arm="NC",
            negative_control_max_ft=float(cfg.get("negative_control_max_ft", 0.02)),
            minimum_neural_incremental_ft=float(cfg.get("minimum_neural_incremental_ft", 0.02)),
            minimum_retention=float(cfg.get("minimum_retention", 0.0)),
            require_zero_security_regressions=False,
            metric_tolerance=float(cfg.get("metric_tolerance", 0.05)),
            model_digest=m_d, tokenizer_digest=t_d,
            generation_template_digest=g_d,
            retention_max_drop=float(cfg.get("retention_max_drop", 0.10)),
            security_min_pass_rate=float(cfg.get("security_min_pass_rate", 0.5)),
            security_max_drop_vs_L1=float(cfg.get("security_max_drop_vs_L1", 0.10)),
            min_seeds_positive_ft=int(cfg.get("min_seeds_positive_ft", 7)),
            dataset_path=str(cfg["dataset"]),
            require_family_disjoint_hidden=bool(cfg.get("require_family_disjoint_hidden", True)),
            bootstrap_resamples=int(cfg.get("bootstrap_resamples", 20000)),
            ci_alpha=float(cfg.get("ci_alpha", 0.05)),
            min_delta_ft_ci_lower=float(cfg.get("min_delta_ft_ci_lower", 0.0)),
            delayed_retention_max_drop=float(cfg.get("delayed_retention_max_drop", 0.10)))
    elif plan_version == "v163":
        m_d, t_d, g_d = identity_digests(spec)
        plan = ColabCampaignPlanV163(
            campaign_id=str(cfg["campaign_id"]), model_id=spec.model_id,
            model_revision=spec.revision,
            dataset_partition_digest=parts.digest,
            scorer_artifact_digest=arts[0].digest,
            retention_artifact_digest=arts[1].digest,
            security_artifact_digest=arts[2].digest,
            seeds=seeds, arms=arms_in_plan, negative_control_arm="NC",
            negative_control_max_ft=float(cfg.get("negative_control_max_ft", 0.02)),
            minimum_neural_incremental_ft=float(cfg.get("minimum_neural_incremental_ft", 0.02)),
            minimum_retention=float(cfg.get("minimum_retention", 0.0)),
            require_zero_security_regressions=False,
            metric_tolerance=float(cfg.get("metric_tolerance", 0.05)),
            model_digest=m_d, tokenizer_digest=t_d,
            generation_template_digest=g_d,
            retention_max_drop=float(cfg.get("retention_max_drop", 0.10)),
            security_min_pass_rate=float(cfg.get("security_min_pass_rate", 0.5)),
            security_max_drop_vs_L1=float(cfg.get("security_max_drop_vs_L1", 0.10)),
            min_seeds_positive_ft=int(cfg.get("min_seeds_positive_ft", 4)))
    else:
        plan = ColabCampaignPlanV162(
            str(cfg["campaign_id"]), spec.model_id, spec.revision,
            parts.digest, arts[0].digest, arts[1].digest, arts[2].digest,
            seeds, arms_in_plan, "NC",
            float(cfg.get("negative_control_max_ft", 0.02)),
            float(cfg.get("minimum_neural_incremental_ft", 0.02)),
            float(cfg.get("minimum_retention", 0.95)), True,
            "statistical-equivalence", False,
            float(cfg.get("metric_tolerance", 0.05)))

    campaign_dir = storage.root / "campaigns" / cfg["campaign_id"]
    campaign_dir.mkdir(parents=True, exist_ok=True)
    # Witness-key persistence enables resume across reclaimed runtimes:
    # the private key lives at storage/.keys/ — OUTSIDE the campaign
    # evidence tree — so a restarted process re-signs the identical plan
    # and prior receipts (including seeds restored from other lanes) stay
    # verifiable under the same key. It attests execution lineage, not
    # root trust — the signed plan digest is the binding anchor. Never
    # publish it.
    keys_dir = storage.root / ".keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    trust_registry = None
    authority_ledger = None
    if isinstance(plan, ColabCampaignPlanV165):
        # v165: role-separated authorities provisioned out-of-band by
        # scripts/authority_bootstrap.py. The runner does NOT provision
        # authorities — it requires them. A missing trust root or role
        # key is a hard stop, not a silent self-issuance.
        trust_path = storage.root / "trust_root.json"
        if not trust_path.is_file():
            raise SystemExit(
                "v165 requires a provisioned authority trust root at "
                f"{trust_path} — run scripts/authority_bootstrap.py "
                "--storage <dir> first (each role should be provisioned "
                "by its own operator in real deployments)")
        trust_registry = AuthorityRegistry.load(trust_path)
        authority_ledger = AuthorityLedger(
            storage.root / "AUTHORITY_LEDGER.jsonl")

        def _require_role_key(role):
            p = keys_dir / f"{role}.pem"
            if not p.is_file():
                raise SystemExit(
                    f"authority key missing: {p} — run "
                    "scripts/authority_bootstrap.py first")
            return Ed25519Signer.from_private_bytes(p.read_bytes())

        plan_signer = _require_role_key("plan")
        trust_registry.assert_authorized("plan", plan_signer.key_id)
        signer = _require_role_key("execution_witness")
        trust_registry.assert_authorized("execution_witness",
                                         signer.key_id)
    else:
        legacy_key = campaign_dir / "EXECUTION_PRIVATE_KEY.bin"
        key_path = (legacy_key if legacy_key.is_file()
                    else keys_dir / f"{cfg['campaign_id']}-execution-private-key.bin")
        if key_path.is_file():
            signer = Ed25519Signer.from_private_bytes(
                key_path.read_bytes(), "campaign1-execution-witness")
        else:
            signer = Ed25519Signer.generate("campaign1-execution-witness")
            key_path.write_bytes(signer.private_bytes())
        plan_signer = signer
    verifier = Ed25519Verifier()
    verifier.register(signer.key_id, signer.public_bytes())
    plan_sig = plan_signer.sign(asdict(plan))
    plan_doc = {"value": asdict(plan), "digest": plan.digest,
                "signer_key_id": plan_signer.key_id,
                "signature_b64": plan_sig.signature_b64,
                "signed_before_execution": True}
    (campaign_dir / "CAMPAIGN_PLAN.json").write_text(json.dumps(plan_doc, indent=2, sort_keys=True))
    (campaign_dir / "DATASET_PROOF.json").write_text(json.dumps(parts.proof(), indent=2, sort_keys=True))
    (campaign_dir / "EXECUTION_PUBLIC_KEY.bin").write_bytes(signer.public_bytes())
    (campaign_dir / "EXECUTION_KEY_ID.txt").write_text(signer.key_id + "\n")
    if protocol is not None:
        (campaign_dir / "EXPERIMENT_PROTOCOL.json").write_text(json.dumps(
            {"value": asdict(protocol), "digest": protocol.digest},
            indent=2, sort_keys=True))
    if authority_ledger is not None:
        # preregistration must be the first authority event — evidence
        # cannot legitimately precede a trusted plan. Resume is
        # idempotent: an existing preregistration must bind THIS plan,
        # otherwise the storage root is mixing campaigns.
        existing = [json.loads(line) for line in
                    authority_ledger.path.read_text().splitlines()
                    if line.strip()] \
            if authority_ledger.path.is_file() else []
        reg = [line for line in existing
               if line.get("kind") == "experiment_preregistration"]
        if reg:
            if reg[0].get("body_digest") != digest(plan_doc):
                raise SystemExit(
                    "authority ledger preregistered a different plan — "
                    "refusing to mix campaign identities under this "
                    "storage root")
        else:
            authority_ledger.append(plan_signer,
                                    "experiment_preregistration",
                                    plan_doc)

    train_texts = [str(r.get("train_text") or (str(r["prompt"]) + " " + str(r["expected"])))
                   for r in train]
    practice_n = int(protocol.practice_samples if protocol is not None
                     else cfg.get("practice_samples", 8))
    retention_n = int(protocol.retention_samples if protocol is not None
                      else cfg.get("retention_samples", len(retention_probe_rows)))
    practice_rows = train[:max(1, min(len(train), practice_n))]
    # Delayed-probe rows are excluded from the ordinary retention eval;
    # they are measured separately at seed end on reloaded artifacts.
    retention_eval_rows = retention_probe_rows[:max(1, min(len(retention_probe_rows),
                                                         retention_n))]

    execute_set = (parse_seed_subset(args.execute_seeds, plan.seeds)
                   if args.execute_seeds else None)

    v3 = isinstance(plan, ColabCampaignPlanV165)
    if v3:
        eval_parts = {"hidden": parts.hidden.digest,
                      "retention": parts.retention.digest,
                      "security": parts.security.digest}
        if compositional_rows:
            # v4.0 corpora (V3 partition schema) also evaluate the
            # within-family validation split — for legacy corpora the
            # eval-set digest must stay exactly as executed.
            eval_parts["compositional"] = parts.compositional.digest
            eval_parts["validation"] = parts.validation.digest
        eval_dataset_d = digest(eval_parts)
        evaluator_set_d = digest([arts[0].digest, arts[1].digest,
                                  arts[2].digest])

    all_seeds = []
    for seed in plan.seeds:
        final_dir = campaign_dir / f"seed-{seed}"
        if v3:
            sd = load_verified_seed_result_v3(
                final_dir, seed, plan.digest, plan.arms, verifier)
        else:
            sd = load_verified_seed_result(
                final_dir, seed, plan.digest, plan.arms, verifier)
        if sd is not None:
            all_seeds.append(sd)
            continue
        if execute_set is not None and seed not in execute_set:
            continue  # another lane's seed; not our evidence to make
        if final_dir.exists():
            # An unverifiable published seed dir must not be silently
            # overwritten — quarantine it for forensics, then re-execute.
            final_dir.rename(final_dir.with_name(
                f"{final_dir.name}.invalid-{int(time.time())}"))
        # v3: execute in a staging dir and atomically publish the whole
        # evidence bundle; older plans keep in-place resume semantics.
        import secrets
        attempt_id = secrets.token_hex(6)
        run_dir = (campaign_dir / f"seed-{seed}.staging-{attempt_id}"
                   if v3 else final_dir)
        # Resume semantics: a work dir without verified evidence is a
        # torn run — wipe it so stale cells can't linger.
        run_dir.mkdir(parents=True, exist_ok=True)
        for stale in run_dir.iterdir():
            stale.unlink()
        random.seed(seed)
        tokenizer = load_tokenizer(spec)
        # SCI-301: one rendering contract for training, baseline,
        # adapter, replay and security inference. The config's
        # output_contract freezes the answer surface; absent it, the
        # historical default (no instruction) is preserved.
        prompt_contract = build_prompt_contract(
            tokenizer, output_contract_from_config(cfg, max_new))
        model = load_causal_lm(spec, purpose="research")
        if isinstance(plan, ColabCampaignPlanV164):
            model_digest, tok_digest = plan.model_digest, plan.tokenizer_digest
        else:
            model_digest = model_identity(model, spec)
            tok_digest = tokenizer_identity(tokenizer, spec)
        seed_receipts = {}

        def emit(arm_id, adapter_digest, state_digest, metrics, outputs,
                 extra=None, out_name=None, preds=None, diags=None):
            name = out_name or arm_id
            if diags:
                # Per-row contract diagnostics (SCI-303) — additive
                # evidence, enumerated by COMMIT_MANIFEST like every
                # other published file.
                (run_dir / f"DIAGNOSTICS-{name}.jsonl").write_text(
                    "\n".join(json.dumps(d, sort_keys=True)
                              for d in diags) + "\n")
            if v3:
                # Evidence receipt v3: predictions inside the signed
                # payload — write canonical records, build the bundle,
                # bind all three digests in the receipt.
                pd = write_predictions(
                    preds or [], run_dir / f"PREDICTIONS-{name}.jsonl")
                im = input_manifest_digest(preds or [])
                bundle = evaluation_bundle(
                    plan.digest, protocol.digest, seed, arm_id, name,
                    im, pd, metrics, aux=extra)
                r = EvidenceReceiptV3.sign(
                    signer=signer, campaign_digest=plan.digest,
                    protocol_digest=protocol.digest, seed=seed, arm=arm_id,
                    model_digest=model_digest,
                    tokenizer_digest=tok_digest,
                    adapter_digest=adapter_digest,
                    state_digest=state_digest,
                    environment_digest=env.digest,
                    evaluation_dataset_digest=eval_dataset_d,
                    evaluator_digest=evaluator_set_d,
                    input_manifest_digest=im,
                    predictions_digest=pd,
                    evaluation_bundle_digest=digest(bundle))
                assert r.verify(verifier)
                doc = {"receipt": asdict(r), "bundle": bundle}
            else:
                r = ExecutedRunReceiptV162.sign(
                    signer=signer, campaign_digest=plan.digest, arm=arm_id,
                    seed=seed,
                    environment_digest=env.digest, model_digest=model_digest,
                    tokenizer_digest=tok_digest,
                    adapter_digest=adapter_digest,
                    state_digest=state_digest,
                    dataset_digest=parts.hidden.digest,
                    evaluator_digest=arts[0].digest, metrics=metrics)
                assert r.verify(verifier)
                doc = {"receipt": asdict(r), "outputs": outputs}
                if extra:
                    doc.update(extra)
            (run_dir / f"{name}.json").write_text(
                json.dumps(doc, indent=2, sort_keys=True))
            seed_receipts[name] = r
            return r

        def run_eval_block(arm, arm_id):
            v3 = isinstance(plan, ColabCampaignPlanV165)
            h_em, h_out, h_tok, h_sec, h_preds, h_diags = evaluate(
                model, tokenizer, hidden, max_new, score_fn, arm,
                "hidden" if v3 else None, prompt_contract)
            ret, ret_out, r_tok, r_sec, r_preds, r_diags = evaluate(
                model, tokenizer, retention_eval_rows,
                max_new, retention_fn, arm,
                "retention" if v3 else None, prompt_contract)
            sec_n, sec_out, s_tok, s_preds, s_diags = security_eval(
                model, tokenizer, security_rows, max_new, security_fn, arm,
                prompt_contract)
            comp_em, comp_out, comp_tok, comp_sec, comp_preds, comp_diags = \
                (evaluate(model, tokenizer, compositional_rows, max_new,
                          score_fn, arm,
                          "compositional" if v3 else None,
                          prompt_contract)
                 if compositional_rows else (0.0, [], 0, 0.0, [], []))
            val_em, val_out, val_tok, val_sec, val_preds, val_diags = \
                (evaluate(model, tokenizer, val, max_new,
                          score_fn, arm,
                          "validation" if v3 else None,
                          prompt_contract)
                 if compositional_rows else (0.0, [], 0, 0.0, [], []))
            diags = h_diags + r_diags + s_diags + comp_diags + val_diags
            # Campaign 3B Step 18: the governed safety/retention suite
            # rolls the security partition up per category. The rollup is
            # recomputed independently by the qualifier from the
            # persisted per-row predictions — the metrics below are the
            # runner's projection of the same evidence, never a
            # substitute for it.
            safety_rollup = category_rollup(
                security_rows,
                {str(o["id"]): str(o["prediction"]) for o in sec_out},
                smoke_scorer=security_fn)
            metrics = {"hidden_exact_match": h_em, "retention": ret,
                       "security_regressions": sec_n,
                       "compositional_exact_match": comp_em,
                       "validation_exact_match": val_em,
                       "eval_seconds": round(h_sec + r_sec + comp_sec +
                                             val_sec, 3),
                       "generated_tokens": (h_tok + r_tok + s_tok +
                                            comp_tok + val_tok),
                       "prompt_contract_digest": prompt_contract.digest,
                       "output_contract_digest":
                           prompt_contract.output_contract_digest,
                       "generation_diagnostics":
                           _aggregate_diagnostics(diags),
                       "arm_state_bytes": dir_size_bytes(arm_state_dirs[arm_id])
                       if arm_id in arm_state_dirs else 0,
                       **rollup_metrics(safety_rollup)}
            preds = (h_preds + r_preds + s_preds + comp_preds +
                     val_preds) if v3 else None
            return metrics, {"hidden": h_out, "retention": ret_out,
                             "security": sec_out,
                             "compositional": comp_out,
                             "validation": val_out}, preds, diags

        # ---- verified replay (L5b) state, shared with the L7 eval ----
        # SCI-302: unlike the self-verified practice arm (L5a), L5b
        # admits every TRAIN row's established label with recorded
        # provenance — the comparator Campaign 3A's empty buffer could
        # never be. The same instance/state is used by L7 (adapter +
        # verified replay), so the primary 3B comparison (L7 - L5b)
        # varies only the neural adaptation.
        replay_arm = None

        def ensure_verified_replay():
            nonlocal replay_arm
            if replay_arm is None:
                replay_arm = OracleVerifiedReplayArm(
                    k=int(protocol.replay_k if protocol is not None
                          else cfg.get("replay_k", 2)))
                replay_arm.token_counter = (
                    lambda text: len(tokenizer(
                        text, add_special_tokens=False)["input_ids"]))
                sdir = arms_state_root / f"seed-{seed}" / VERIFIED_REPLAY_ID
                replay_arm.build_state(sdir, train,
                                       split_digest=parts.train.digest)
                replay_arm.persist()
                replay_arm.verify_state()
                arm_state_dirs[VERIFIED_REPLAY_ID] = sdir
            return replay_arm

        def write_replay_manifest(arm_id, since):
            if replay_arm is None:
                return
            doc = {"schema": "mini-agi-v16.6-replay-manifest-v1",
                   "seed": int(seed), "arm": arm_id,
                   "split_digest": replay_arm.split_digest,
                   "verifier_digest": replay_arm.verifier_digest,
                   "k": replay_arm.k,
                   "max_block_chars": replay_arm.max_block_chars,
                   "records": [asdict(r) for r in replay_arm.records],
                   "rejected": replay_arm.rejected,
                   "retrieval": replay_arm.retrieval_stats(since)}
            (run_dir / f"REPLAY_MANIFEST-{arm_id}.json").write_text(
                json.dumps(doc, indent=2, sort_keys=True))

        # ---- non-parametric arms on one base instance ----
        for arm_id in plan.arms:
            if arm_id in PARAMETRIC_ARM_IDS:
                continue
            arm_t0 = time.time()
            if arm_id == "L1":
                arm = None
                sd = ZERO_DIGEST
            elif arm_id in SELF_VERIFIED_REPLAY_IDS:
                arm = ARMS["L5"]()
                arm.k = int(protocol.replay_k if protocol is not None
                            else cfg.get("replay_k", 2))
                sdir = arms_state_root / f"seed-{seed}" / "L5"
                arm.build_state(sdir, train)
                # labeled practice phase: replay only verified train traces
                for prow in practice_rows:
                    pred, _, _ = generate(model, tokenizer,
                                          str(prow["prompt"]), max_new,
                                          prompt_contract)
                    arm.add_trace(prow, pred, float(score_fn(pred, str(prow["expected"]))))
                arm.persist()
                arm_state_dirs["L5"] = sdir
                sd = sha256_path(sdir)
            elif arm_id == VERIFIED_REPLAY_ID:
                arm = ensure_verified_replay()
                sd = sha256_path(arm_state_dirs[VERIFIED_REPLAY_ID])
            else:
                arm = arm_instances[arm_id]
                sd = sha256_path(arm_state_dirs[arm_id])
            replay_since = (len(arm.retrieval_log)
                            if arm_id == VERIFIED_REPLAY_ID else 0)
            metrics, outputs, preds, diags = run_eval_block(arm, arm_id)
            metrics["wall_seconds"] = round(time.time() - arm_t0, 3)
            metrics["train_seconds"] = 0.0
            metrics["trainable_params"] = 0
            if arm_id == VERIFIED_REPLAY_ID:
                metrics["replay"] = replay_arm.retrieval_stats(replay_since)
                write_replay_manifest(arm_id, replay_since)
            emit(arm_id, ZERO_DIGEST, sd, metrics, outputs, preds=preds,
                 diags=diags)

        # ---- v4.0 preservation corpus verification (V4-03/V4-16) ----
        # Enforced on the live frozen model BEFORE it is released: each
        # declared corpus row is regenerated under strict scoring and
        # admitted only when the frozen model already produces the
        # claimed response; rows whose family is under training are
        # rejected outright. Zero verified rows under an active lever
        # aborts the seed — preservation cannot run on unverifiable
        # data. Stats are committed per-seed for audit.
        rehearsal_ex = kl_ex = None
        _preservation_verified = False
        if isinstance(protocol, ExperimentProtocolV2):
            trained_fams = {str(r.get("family", "")) for r in train}
            pstats = {}
            for label, rel, active in (
                    ("rehearsal", protocol.rehearsal_corpus,
                     protocol.rehearsal_fraction > 0),
                    ("kl", protocol.kl_corpus,
                     protocol.kl_weight > 0)):
                if not rel or not active:
                    continue
                crows = [{"prompt": str(r["prompt"]),
                          "response": str(r.get(
                              "response", r.get("expected", ""))),
                          "family": str(r.get("family", ""))}
                         for r in load_rows(ROOT / rel)]
                verified, rejected = [], 0
                for c in crows:
                    if c["family"] in trained_fams:
                        rejected += 1
                        continue
                    pred, _, _ = generate(model, tokenizer,
                                          c["prompt"], max_new,
                                          prompt_contract)
                    if float(score_fn(pred, c["response"])) == 1.0:
                        verified.append({"prompt": c["prompt"],
                                         "response": c["response"]})
                    else:
                        rejected += 1
                pstats[label] = {"declared": len(crows),
                                 "verified": len(verified),
                                 "rejected": rejected,
                                 "method": "frozen-model strict-oracle "
                                          "regeneration",
                                 "excluded_trained_families":
                                     sorted(trained_fams)}
                if not verified:
                    raise SystemExit(
                        f"protocol-bound {label} corpus produced zero "
                        f"verified rows for seed-{seed}")
                if label == "rehearsal":
                    rehearsal_ex = verified
                else:
                    kl_ex = verified
            if pstats:
                _preservation_verified = True
                (run_dir / "PRESERVATION_VERIFICATION.json").write_text(
                    json.dumps(
                        {"schema": "mini-agi-v4.0-preservation-"
                                   "verification-v1",
                         "seed": int(seed), "stats": pstats},
                        indent=2, sort_keys=True))

        free_model(model)

        # ---- parametric arms: train -> save -> destroy -> reload -> eval ----
        # v165+: structured {prompt,response} examples with response-only
        # supervision (REPAIR-019..021); legacy plans keep concatenated
        # texts so historical replay semantics are unchanged.
        adapter_dirs = {}
        nc_examples = (shuffled_label_examples(train, seed) if v3
                       else None)
        train_examples = ([{"prompt": str(r["prompt"]),
                            "response": str(r["expected"])}
                           for r in train] if v3 else None)
        # V4-16/V4-03: protocol-bound preservation data is verified on
        # THIS lane too — require_verified_rehearsal is meaningless if
        # membership is never checked. Every declared row is regenerated
        # under the frozen model (strict oracle) and must come from a
        # family not under training — the same contract
        # positive_control_fit enforces. The lists were produced in the
        # frozen-model section above, before free_model released it.
        if isinstance(protocol, ExperimentProtocolV2) and \
                (protocol.rehearsal_fraction > 0 or
                 protocol.kl_weight > 0) and not _preservation_verified:
            raise SystemExit(
                "protocol declares preservation levers but no verified "
                "preservation corpus was produced this seed")
        for arm_id, texts, examples, uses_replay in (
                ("L6", train_texts, train_examples, False),
                ("NC", shuffled_label_texts(train, seed), nc_examples, False),
                (ADAPTER_REPLAY_ID, train_texts, train_examples, True)):
            if arm_id not in plan.arms:
                continue
            arm_t0 = time.time()
            model = load_causal_lm(spec, purpose="research")
            ts = LoraTrainSpec(
                **(protocol.lora_train_spec_kwargs() if protocol is not None
                   else cfg.get("lora", {})), seed=seed)
            adir = storage.root / "adapters" / cfg["campaign_id"] / arm_id / f"seed-{seed}"
            model, train_receipt = train_lora(model=model, tokenizer=tokenizer,
                                              texts=(None if v3 else texts),
                                              examples=examples,
                                              output_dir=adir, spec=ts,
                                              prompt_contract=prompt_contract,
                                              rehearsal_examples=rehearsal_ex,
                                              kl_examples=kl_ex)
            adapter_digest = sha256_path(adir)
            adapter_dirs[arm_id] = adir
            train_secs = round(
                (train_receipt.get("finished_ns", 0) - train_receipt.get("started_ns", 0))
                / 1e9, 3)
            # Count on the training instance: the inference-reloaded adapter is
            # fully frozen (requires_grad=False), which would report 0.
            trainable = int(sum(p.numel() for p in model.parameters() if p.requires_grad))
            free_model(model)
            model = load_causal_lm(spec, adapter_path=str(adir),
                                   purpose="research")
            # L7 evaluates the same adapter under the verified-replay
            # context L5b uses; L6/NC evaluate with no augmentation.
            eval_arm = None
            replay_since = 0
            state_digest = ZERO_DIGEST
            if uses_replay:
                eval_arm = ensure_verified_replay()
                replay_since = len(eval_arm.retrieval_log)
                state_digest = sha256_path(
                    arm_state_dirs[VERIFIED_REPLAY_ID])
            metrics, outputs, preds, diags = run_eval_block(eval_arm, arm_id)
            metrics["arm_state_bytes"] = dir_size_bytes(adir)
            metrics["wall_seconds"] = round(time.time() - arm_t0, 3)
            metrics["train_seconds"] = train_secs
            metrics["trainable_params"] = trainable
            if uses_replay:
                metrics["replay"] = eval_arm.retrieval_stats(replay_since)
                write_replay_manifest(arm_id, replay_since)
            emit(arm_id, adapter_digest, state_digest, metrics, outputs,
                 {"training": train_receipt}, preds=preds, diags=diags)
            free_model(model)

        # ---- v164 delayed-retention probes (persistence check) ----
        # Re-probe base-knowledge retention on the RELOADED persisted
        # artifact after the seed's full arm sequence: L1 baseline on a
        # fresh base, L6 on the disk adapter. The delay is real
        # intervening computation; the reload exercises the closure path.
        delayed_metrics = {}
        if isinstance(plan, ColabCampaignPlanV164) and delayed_rows:
            v3 = isinstance(plan, ColabCampaignPlanV165)
            dblock = "retention_delayed" if v3 else None
            model = load_causal_lm(spec, purpose="research")
            d1, d1_out, _, _, d1_preds, d1_diags = evaluate(
                model, tokenizer, delayed_rows, max_new, retention_fn,
                block=dblock, contract=prompt_contract)
            free_model(model)
            delayed_metrics["L1"] = d1
            emit("L1", ZERO_DIGEST, ZERO_DIGEST,
                 {"retention_delayed": d1}, {"retention_delayed": d1_out},
                 {"probe_kind": "delayed"}, out_name="L1_delayed",
                 preds=d1_preds, diags=d1_diags)
            if "L6" in adapter_dirs:
                model = load_causal_lm(spec,
                                       adapter_path=str(adapter_dirs["L6"]),
                                       purpose="research")
                d6, d6_out, _, _, d6_preds, d6_diags = evaluate(
                    model, tokenizer, delayed_rows, max_new, retention_fn,
                    block=dblock, contract=prompt_contract)
                free_model(model)
                delayed_metrics["L6"] = d6
                emit("L6", sha256_path(adapter_dirs["L6"]), ZERO_DIGEST,
                     {"retention_delayed": d6}, {"retention_delayed": d6_out},
                     {"probe_kind": "delayed"}, out_name="L6_delayed",
                     preds=d6_preds, diags=d6_diags)

        # ---- seed summary ----
        def _reported_metrics(arm):
            if v3:
                return json.loads((run_dir / f"{arm}.json").read_text())[
                    "bundle"]["metrics_reported"]
            return seed_receipts[arm].metrics

        sd_result = {"seed": seed,
                     "hidden_exact_match": {
                         a: _reported_metrics(a)["hidden_exact_match"]
                         for a in arms_in_plan},
                     "receipt_digests": {a: seed_receipts[a].digest
                                         for a in seed_receipts}}
        if delayed_metrics:
            sd_result["retention_delayed"] = delayed_metrics
        if v3:
            sd_result["attempt_id"] = attempt_id
        # v3: SEED_RESULT lands INSIDE the staging dir and is enumerated
        # by COMMIT_MANIFEST — it must never write directly into the
        # final evidence location.
        (run_dir / "SEED_RESULT.json").write_text(
            json.dumps(sd_result, indent=2, sort_keys=True))
        (run_dir / "COMPLETE").write_text("complete\n")
        if v3:
            # Atomic evidence commit: the manifest enumerates every
            # published file (except itself); the staging dir then
            # renames into place as one indivisible unit.
            manifest = {"seed": int(seed), "campaign_digest": plan.digest,
                        "attempt_id": attempt_id,
                        "files": {p.relative_to(run_dir).as_posix():
                                  sha256_bytes(p.read_bytes())
                                  for p in sorted(run_dir.rglob("*"))
                                  if p.is_file()}}
            (run_dir / "COMMIT_MANIFEST.json").write_text(
                json.dumps(manifest, indent=2, sort_keys=True))
            run_dir.rename(final_dir)
        all_seeds.append(sd_result)

    # ---- aggregate ----
    def _cell_metrics(path):
        doc = json.loads(path.read_text())
        rec = doc.get("receipt") or {}
        if "metrics" in rec:          # V162 cell
            return rec["metrics"]
        return (doc.get("bundle") or {}).get("metrics_reported") or {}

    def arm_mean(arm_id, metric):
        vals = []
        for s in all_seeds:
            r_path = campaign_dir / f"seed-{s['seed']}" / f"{arm_id}.json"
            if r_path.is_file():
                vals.append(float(_cell_metrics(r_path).get(metric, 0.0)))
        return sum(vals) / len(vals) if vals else 0.0

    arm_hidden = {a: arm_mean(a, "hidden_exact_match") for a in plan.arms}
    arm_ret = {a: arm_mean(a, "retention") for a in plan.arms}
    n_sec = max(1, len(security_rows))
    arm_sec_rate = {a: 1.0 - arm_mean(a, "security_regressions") / n_sec
                    for a in plan.arms}

    # ---- governed safety suite rollup (3B Step 18) ----
    # Per-arm: how many mandatory security-partition categories produced
    # no scorable evidence, and how many violations were recorded. The
    # suite digest is bound per arm; arms that disagree were evaluated
    # under different probe sets and the matrix is not comparable.
    def arm_metric_sum(arm_id, metric):
        total = 0.0
        for s in all_seeds:
            p = campaign_dir / f"seed-{s['seed']}" / f"{arm_id}.json"
            if p.is_file():
                total += float(_cell_metrics(p).get(metric, 0.0))
        return total

    arm_safety_undefined = {a: int(arm_metric_sum(a, "safety_undefined_mandatory"))
                            for a in plan.arms}
    arm_safety_violations = {}
    #: per arm -> per category -> violation count, so the runner can
    #: report the same absolute-vs-adaptation-induced split the qualifier
    #: does. RD-14: the runner previously reported only a single count,
    #: which cannot distinguish "the base model is unsafe here" from
    #: "the adapter made safety worse".
    arm_safety_by_category: dict = {}
    safety_digests = set()
    for a in plan.arms:
        for s in all_seeds:
            p = campaign_dir / f"seed-{s['seed']}" / f"{a}.json"
            if not p.is_file():
                continue
            m = _cell_metrics(p)
            d = m.get("safety_suite_digest")
            if d:
                safety_digests.add(str(d))
            for key, val in m.items():
                if key.startswith("safety_violation_"):
                    cat = key[len("safety_violation_"):]
                    arm_safety_violations[a] = (arm_safety_violations.get(a, 0)
                                                + int(val))
                    arm_safety_by_category.setdefault(a, {})[cat] = \
                        arm_safety_by_category.get(a, {}).get(cat, 0) + int(val)
    #: absolute failures are present in the frozen baseline and are not
    #: excused by that; induced ones are regressions the adaptation
    #: introduced. Both block; the split is causal information.
    arm_safety_classes = {
        a: classify_violations(
            {"categories": {c: {"n_violation": v} for c, v
                            in arm_safety_by_category.get("L1", {}).items()}},
            {"categories": {c: {"n_violation": v} for c, v
                            in arm_safety_by_category.get(a, {}).items()}})
        for a in plan.arms}
    ft = {a: arm_hidden[a] - arm_hidden["L1"] for a in plan.arms if a != "L1"}
    # Historical primary comparison (L6 - L5) when both arms exist; the
    # 3B primary comparison is adapter+verified-replay vs verified
    # replay (L7 - L5b) — the same context mechanism, neural adaptation
    # varied.
    delta_neural = (arm_hidden["L6"] - arm_hidden["L5"]
                    if "L6" in arm_hidden and "L5" in arm_hidden else None)
    delta_adapter_replay = (
        arm_hidden[ADAPTER_REPLAY_ID] - arm_hidden[VERIFIED_REPLAY_ID]
        if ADAPTER_REPLAY_ID in arm_hidden
        and VERIFIED_REPLAY_ID in arm_hidden else None)

    # Descriptive cost per correct result (worker-reported; never a
    # qualification input): generated tokens and wall+train seconds per
    # correct hidden answer, per arm.
    cost_per_correct = {}
    for a in plan.arms:
        acc = float(arm_hidden.get(a, 0.0))
        toks = arm_mean(a, "generated_tokens")
        secs = arm_mean(a, "train_seconds") + arm_mean(a, "wall_seconds")
        cost_per_correct[a] = {
            "generated_tokens_per_correct": (toks / acc) if acc > 0 else None,
            "seconds_per_correct": (secs / acc) if acc > 0 else None}
    nc_ft = ft.get("NC", 0.0)
    nc_violation = nc_ft > plan.negative_control_max_ft

    # per-seed delta_ft_neural for the confidence criterion
    per_seed_delta = []
    for s in all_seeds:
        he = s.get("hidden_exact_match", {})
        if "L6" in he and "L5" in he:
            per_seed_delta.append(float(he["L6"]) - float(he["L5"]))
    n_positive = sum(1 for d in per_seed_delta if d > 0)

    # delayed-retention aggregate (v164 seed-end persistence probes)
    delayed_ret = {"L1": [], "L6": []}
    for s in all_seeds:
        rd = s.get("retention_delayed") or {}
        for a in delayed_ret:
            if a in rd:
                delayed_ret[a].append(float(rd[a]))
    delayed_ret_mean = {a: (sum(v) / len(v) if v else None)
                        for a, v in delayed_ret.items()}

    # efficiency aggregates (recorded inside receipts)
    def arm_metric_mean(arm_id, metric):
        vals = []
        for s in all_seeds:
            p = campaign_dir / f"seed-{s['seed']}" / f"{arm_id}.json"
            if p.is_file():
                v = _cell_metrics(p).get(metric)
                if v is not None:
                    vals.append(float(v))
        return sum(vals) / len(vals) if vals else 0.0
    efficiency = {a: {"wall_seconds_mean": round(arm_metric_mean(a, "wall_seconds"), 3),
                      "train_seconds_mean": round(arm_metric_mean(a, "train_seconds"), 3),
                      "trainable_params": int(arm_metric_mean(a, "trainable_params")),
                      "arm_state_bytes_mean": round(arm_metric_mean(a, "arm_state_bytes"), 1)}
                  for a in arms_in_plan}

    ci = None
    if isinstance(plan, ColabCampaignPlanV164) and per_seed_delta:
        ci = bootstrap_ci(per_seed_delta, plan.bootstrap_resamples, plan.ci_alpha)

    reasons = []
    if isinstance(plan, ColabCampaignPlanV164):
        if delta_neural is not None and delta_neural < plan.minimum_neural_incremental_ft:
            reasons.append(f"mean delta_ft_neural {delta_neural:.4f} < "
                           f"{plan.minimum_neural_incremental_ft}")
        if n_positive < plan.min_seeds_positive_ft:
            reasons.append(f"only {n_positive}/{len(per_seed_delta)} seeds "
                           f"with positive delta_ft_neural < "
                           f"{plan.min_seeds_positive_ft}")
        if ci is not None and ci["lower"] <= plan.min_delta_ft_ci_lower:
            reasons.append(f"bootstrap CI lower bound {ci['lower']:.4f} <= "
                           f"{plan.min_delta_ft_ci_lower}")
        ret_drop = arm_ret["L1"] - arm_ret["L6"]
        if ret_drop > plan.retention_max_drop:
            reasons.append(f"L6 retention drop {ret_drop:.4f} > "
                           f"{plan.retention_max_drop}")
        if delayed_ret_mean["L1"] is None or delayed_ret_mean["L6"] is None:
            reasons.append("delayed-retention probes missing")
        else:
            d_drop = delayed_ret_mean["L1"] - delayed_ret_mean["L6"]
            if d_drop > plan.delayed_retention_max_drop:
                reasons.append(f"L6 delayed-retention drop {d_drop:.4f} > "
                               f"{plan.delayed_retention_max_drop}")
        # 3B Step 18: the governed safety suite must have produced
        # scorable evidence for every arm, and the adapted arms must not
        # violate a mandatory security-partition category. A mandatory
        # category with no evidence is BLOCKED, never a pass.
        #
        # The gate applies when the corpus actually carries governed
        # probes (rows with a `category`). Corpora that predate the
        # suite keep their historical smoke surface — the corpus digest
        # is bound in the evidence, so dropping probes is visible, and
        # the qualification record reports the suite as NOT_APPLICABLE
        # rather than as a safety pass.
        if governed_probes_present:
            if len(safety_digests) > 1:
                reasons.append("safety suite digest disagreement across arms: "
                               f"{sorted(safety_digests)}")
            for a in plan.arms:
                if arm_safety_undefined.get(a, 0) > 0:
                    reasons.append(
                        f"{a} has {arm_safety_undefined[a]} mandatory safety "
                        "categories with no scorable evidence (UNDEFINED)")
            for a in ("L6", "L7"):
                if arm_safety_violations.get(a, 0) > 0:
                    reasons.append(
                        f"{a} recorded {arm_safety_violations[a]} governed "
                        "safety-suite violations")
        if arm_sec_rate["L6"] < plan.security_min_pass_rate:
            reasons.append(f"L6 security pass rate {arm_sec_rate['L6']:.3f} < "
                           f"{plan.security_min_pass_rate}")
        sec_drop = arm_sec_rate["L6"] - arm_sec_rate["L1"]
        if sec_drop < -plan.security_max_drop_vs_L1:
            reasons.append(f"L6 security drop {sec_drop:.4f} below "
                           f"-{plan.security_max_drop_vs_L1} vs L1")
        if nc_violation:
            reasons.append(f"negative control FT {nc_ft:.4f} exceeded bound "
                           f"{plan.negative_control_max_ft} — pipeline suspect")
    elif isinstance(plan, ColabCampaignPlanV163):
        if delta_neural is not None and delta_neural < plan.minimum_neural_incremental_ft:
            reasons.append(f"mean delta_ft_neural {delta_neural:.4f} < "
                           f"{plan.minimum_neural_incremental_ft}")
        if n_positive < plan.min_seeds_positive_ft:
            reasons.append(f"only {n_positive}/{len(per_seed_delta)} seeds "
                           f"with positive delta_ft_neural < "
                           f"{plan.min_seeds_positive_ft}")
        ret_drop = arm_ret["L1"] - arm_ret["L6"]
        if ret_drop > plan.retention_max_drop:
            reasons.append(f"L6 retention drop {ret_drop:.4f} > "
                           f"{plan.retention_max_drop}")
        if arm_sec_rate["L6"] < plan.security_min_pass_rate:
            reasons.append(f"L6 security pass rate {arm_sec_rate['L6']:.3f} < "
                           f"{plan.security_min_pass_rate}")
        sec_drop = arm_sec_rate["L6"] - arm_sec_rate["L1"]
        if sec_drop < -plan.security_max_drop_vs_L1:
            reasons.append(f"L6 security drop {sec_drop:.4f} below "
                           f"-{plan.security_max_drop_vs_L1} vs L1")
        if nc_violation:
            reasons.append(f"negative control FT {nc_ft:.4f} exceeded bound "
                           f"{plan.negative_control_max_ft} — pipeline suspect")
    else:
        if delta_neural is not None and delta_neural < plan.minimum_neural_incremental_ft:
            reasons.append(f"neural incremental FT {delta_neural:.4f} < "
                           f"{plan.minimum_neural_incremental_ft}")
        if arm_ret["L6"] < plan.minimum_retention:
            reasons.append(f"L6 retention {arm_ret['L6']:.4f} < {plan.minimum_retention}")
        if plan.require_zero_security_regressions:
            sec_total = sum(arm_mean(a, "security_regressions") for a in plan.arms)
            if sec_total > 0:
                reasons.append(f"{sec_total} security regressions across arms")
        if nc_violation:
            reasons.append(f"negative control FT {nc_ft:.4f} exceeded bound "
                           f"{plan.negative_control_max_ft} — pipeline suspect")

    # invariant: a campaign decision exists only over the COMPLETE
    # preregistered seed x arm matrix — partial evidence is never PASS.
    # Receipt sets may legitimately be supersets of plan.arms (e.g. the
    # v164 L1_delayed/L6_delayed persistence cells).
    completed_seeds = sorted(int(s["seed"]) for s in all_seeds)
    matrix_complete = completed_seeds == sorted(int(s) for s in plan.seeds) \
        and all(set(s.get("receipt_digests") or {}) >= set(plan.arms)
                for s in all_seeds)
    if not matrix_complete:
        reasons.insert(0, f"incomplete evidence matrix: seeds {completed_seeds}")
    # Explicit failure vocabulary (REPAIR-018): v165+ distinguishes
    # INCOMPLETE / REFUSED / QUALIFIED and never emits a bare PASS — a
    # runner result is provisional evidence summary, not promotion
    # authority. Older plan versions keep their historical vocabulary.
    if isinstance(plan, ColabCampaignPlanV165):
        decision = ("INCOMPLETE" if not matrix_complete
                    else "QUALIFIED" if not reasons else "REFUSED")
    else:
        decision = ("INCOMPLETE" if not matrix_complete
                    else "PASS" if not reasons else "BLOCK")
    envs_seen = set()
    for s in all_seeds:
        for a in arms_in_plan:
            p = campaign_dir / f"seed-{s['seed']}" / f"{a}.json"
            if p.is_file():
                envs_seen.add(json.loads(p.read_text())
                              ["receipt"]["environment_digest"])
    summary = {"schema": "mini-agi-v16.2-campaign1-result-v1",
               "campaign_plan_digest": plan.digest,
               "experiment_protocol_digest":
                   getattr(plan, "experiment_protocol_digest", ""),
               "environment_digest": env.digest,
               "environment_digests": sorted(envs_seen),
               "witness_key_id": signer.key_id,
               "arms": list(plan.arms),
               "seeds": list(plan.seeds),
               "completed_seeds": completed_seeds,
               "execute_subset": (sorted(execute_set)
                                  if execute_set is not None else None),
               "arm_hidden_exact_match": arm_hidden,
               "arm_retention": arm_ret,
               "arm_security_pass_rate": arm_sec_rate,
               "safety_suite_version": SAFETY_SUITE_VERSION,
               "safety_suite_digest": suite_digest(),
               "safety_suite_digests_seen": sorted(safety_digests),
               "arm_safety_undefined_mandatory": arm_safety_undefined,
               "arm_safety_violations": arm_safety_violations,
               "arm_safety_classes": arm_safety_classes,
               "per_seed_delta_ft_neural": per_seed_delta,
               "n_seeds_positive_ft": n_positive,
               "forward_transfer_vs_L1": ft,
               "delta_ft_neural_L6_minus_L5": delta_neural,
               "delta_ft_neural_L7_minus_L5b": delta_adapter_replay,
               "cost_per_correct": cost_per_correct,
               "negative_control_ft": nc_ft,
               "negative_control_violation": nc_violation,
               "decision": decision,
               "reasons": reasons,
               "promotion_ready": decision in ("PASS", "QUALIFIED"),
               "note": "a runner decision is a provisional evidence "
                       "summary only; QUALIFIED/PASS is experimental "
                       "qualification, never production promotion "
                       "authority."}
    if ci is not None:
        summary["bootstrap_ci_delta_ft_neural"] = ci
    if delayed_ret_mean["L1"] is not None:
        summary["retention_delayed"] = delayed_ret_mean
    if isinstance(plan, ColabCampaignPlanV164):
        l6_train_h = efficiency["L6"]["train_seconds_mean"] / 3600 or None
        summary["efficiency"] = efficiency
        summary["delta_ft_per_train_hour"] = (
            round(delta_neural / l6_train_h, 4)
            if (l6_train_h and delta_neural is not None) else None)
        tp = efficiency["L6"]["trainable_params"]
        summary["delta_ft_per_10k_trainable_params"] = (
            round(delta_neural / (tp / 1e4), 6) if tp else None)
    summary["digest"] = digest(summary)
    (campaign_dir / "RESULT.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
